About Dataset
Potato Disease Dataset

The dataset was compiled from numerous websites and validated by Bangladesh Agricultural Research Institute (BARI).

Disease Information

Disease Name		Total Images	Causes of Disease
Common scab		62		Bacteria
Blackleg		60		Bacteria
Dry rot			60		Fungus
Pink rot		57		Fungus
Black scurf		58		Fungus
Healthy Potatoes	80		-
Miscellaneous		74		-
Total			451		-
